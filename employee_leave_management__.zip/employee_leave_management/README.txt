SETUP STEPS
============
1. pip install -r requirements.txt
   (mysqlclient needs MySQL dev headers installed on your OS -
    on Ubuntu: sudo apt-get install python3-dev default-libmysqlclient-dev build-essential)

2. In MySQL, create the database:
   CREATE DATABASE employee_leave_db;

3. Update employee_leave_management/settings.py as described in settings_changes.txt

4. Run migrations:
   python manage.py makemigrations
   python manage.py migrate

5. Create an admin user (optional, to use Django admin panel):
   python manage.py createsuperuser

6. Start the server:
   python manage.py runserver


API ENDPOINTS
==============
Employee APIs (Module 1 + 6):
  GET    /api/employees/            -> list all employees
  GET    /api/employees/<id>/       -> get one employee
  POST   /api/employees/            -> create employee
  PUT    /api/employees/<id>/       -> update employee
  DELETE /api/employees/<id>/       -> delete employee
  GET    /api/employees/?search=John   -> search by name or ID (Module 4)

  Example POST body:
  {
      "name": "Rahul Sharma",
      "email": "rahul@example.com",
      "department": "IT",
      "mobile_number": "9876543210",
      "date_of_joining": "2024-01-15"
  }

Leave APIs (Module 2 + 6):
  GET    /api/leaves/               -> list all (Module 2: view leave history)
  GET    /api/leaves/<id>/          -> get one leave
  POST   /api/leaves/               -> apply for leave
  PUT    /api/leaves/<id>/          -> edit leave
  DELETE /api/leaves/<id>/          -> delete leave
  GET    /api/leaves/?status=Pending          -> filter by status (Module 5)
  GET    /api/leaves/?leave_type=Sick         -> filter by leave type (Module 5)
  GET    /api/leaves/?search=Rahul            -> search by employee name/ID (Module 4)

  Example POST body:
  {
      "employee": 1,
      "leave_type": "Casual",
      "from_date": "2026-07-20",
      "to_date": "2026-07-22",
      "reason": "Family function"
  }

Dashboard API (Module 3):
  GET /api/dashboard/
  Returns:
  {
      "total_employees": 10,
      "total_leave_applications": 25,
      "pending_requests": 5,
      "approved_requests": 15,
      "rejected_requests": 5
  }


VALIDATION IMPLEMENTED
=======================
- Required fields  -> enforced automatically by DRF serializers (model fields are non-nullable)
- Email format     -> Django's EmailField validates this automatically
- Mobile number    -> RegexValidator on model + extra check in serializer (10 digits)
- From Date <= To Date -> checked in LeaveSerializer.validate()

WHERE TO PUT THESE FILES
=========================
employee/models.py
employee/serializers.py
employee/views.py
employee/urls.py
employee/admin.py

emp_leaves/models.py
emp_leaves/serializers.py
emp_leaves/views.py
emp_leaves/urls.py
emp_leaves/admin.py

employee_leave_management/urls.py   (replace the existing one)
