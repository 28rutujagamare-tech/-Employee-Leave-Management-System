from django.apps import AppConfig


class EmpLeavesConfig(AppConfig):
    name = 'emp_leaves'
