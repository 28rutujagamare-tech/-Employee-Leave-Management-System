from rest_framework import serializers
from .models import Leave


class LeaveSerializer(serializers.ModelSerializer):
    # Extra read-only field so the API response also shows the employee's name
    employee_name = serializers.CharField(source='employee.name', read_only=True)

    class Meta:
        model = Leave
        fields = [
            'id', 'employee', 'employee_name', 'leave_type',
            'from_date', 'to_date', 'reason', 'status'
        ]

    def validate(self, data):
        # On update, some fields might not be sent, so fall back to existing instance values
        from_date = data.get('from_date', getattr(self.instance, 'from_date', None))
        to_date = data.get('to_date', getattr(self.instance, 'to_date', None))

        if from_date and to_date and from_date > to_date:
            raise serializers.ValidationError("From Date must not be greater than To Date")
        return data
