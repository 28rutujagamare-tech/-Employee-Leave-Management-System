from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import (
    LeaveViewSet,
    DashboardAPIView,

    # Django Web Views
    leave_list,
    apply_leave,
    approve_leave,
    reject_leave,
)

router = DefaultRouter()
router.register(r'leaves', LeaveViewSet, basename='leave')

urlpatterns = [

    # ==========================
    # REST API
    # ==========================

    path(
        'dashboard/',
        DashboardAPIView.as_view(),
        name='dashboard_api'
    ),

    # ==========================
    # Django Web Pages
    # ==========================

    path(
        'leave/',
        leave_list,
        name='leave_list'
    ),

    path(
        'leave/apply/',
        apply_leave,
        name='apply_leave'
    ),

    path(
        'leave/approve/<int:id>/',
        approve_leave,
        name='approve_leave'
    ),

    path(
        'leave/reject/<int:id>/',
        reject_leave,
        name='reject_leave'
    ),

]

# DRF Routes
urlpatterns += router.urls