from datetime import datetime

from rest_framework import viewsets, views
from rest_framework.response import Response

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden

from .models import Leave
from .serializers import LeaveSerializer
from employee.models import Employee


# =====================================
# REST API
# =====================================

class LeaveViewSet(viewsets.ModelViewSet):

    queryset = Leave.objects.all().order_by("-id")
    serializer_class = LeaveSerializer

    def get_queryset(self):

        queryset = Leave.objects.all().order_by("-id")

        status = self.request.query_params.get("status")
        leave_type = self.request.query_params.get("leave_type")
        search = self.request.query_params.get("search")

        if status:
            queryset = queryset.filter(status=status)

        if leave_type:
            queryset = queryset.filter(leave_type=leave_type)

        if search:

            if search.isdigit():
                queryset = queryset.filter(employee__id=search)
            else:
                queryset = queryset.filter(employee__name__icontains=search)

        return queryset


# =====================================
# Dashboard API
# =====================================

class DashboardAPIView(views.APIView):

    def get(self, request):

        data = {
            "total_employees": Employee.objects.count(),
            "total_leave_applications": Leave.objects.count(),
            "pending_requests": Leave.objects.filter(status="Pending").count(),
            "approved_requests": Leave.objects.filter(status="Approved").count(),
            "rejected_requests": Leave.objects.filter(status="Rejected").count(),
        }

        return Response(data)


# =====================================
# Django Web Views
# =====================================

@login_required
def leave_list(request):

    # HR can see all leave applications
    if request.user.is_staff:
        leaves = Leave.objects.all().order_by("-id")

    # Employee can see only their own leave history
    else:
        employee = get_object_or_404(Employee, user=request.user)
        leaves = Leave.objects.filter(employee=employee).order_by("-id")

    status = request.GET.get("status")
    leave_type = request.GET.get("leave_type")

    if status:
        leaves = leaves.filter(status=status)

    if leave_type:
        leaves = leaves.filter(leave_type=leave_type)

    context = {
        "leaves": leaves,
    }

    return render(request, "leave/leave_list.html", context)


@login_required
def apply_leave(request):

    if request.method == "POST":

        employee = get_object_or_404(Employee, user=request.user)

        from_date = datetime.strptime(
            request.POST.get("from_date"),
            "%Y-%m-%d"
        ).date()

        to_date = datetime.strptime(
            request.POST.get("to_date"),
            "%Y-%m-%d"
        ).date()

        if from_date > to_date:

            messages.error(
                request,
                "From Date cannot be greater than To Date."
            )

            return render(
                request,
                "leave/apply_leave.html",
            )

        Leave.objects.create(
            employee=employee,
            leave_type=request.POST.get("leave_type"),
            from_date=from_date,
            to_date=to_date,
            reason=request.POST.get("reason"),
            status="Pending",
        )

        messages.success(
            request,
            "Leave Applied Successfully."
        )

        return redirect("leave_list")

    return render(
        request,
        "leave/apply_leave.html",
    )


# =====================================
# HR Approve Leave
# =====================================

@login_required
def approve_leave(request, id):

    if not request.user.is_staff:
        return HttpResponseForbidden("You are not authorized.")

    leave = get_object_or_404(Leave, id=id)

    leave.status = "Approved"
    leave.save()

    messages.success(
        request,
        "Leave Approved Successfully."
    )

    return redirect("leave_list")


# =====================================
# HR Reject Leave
# =====================================

@login_required
def reject_leave(request, id):

    if not request.user.is_staff:
        return HttpResponseForbidden("You are not authorized.")

    leave = get_object_or_404(Leave, id=id)

    leave.status = "Rejected"
    leave.save()

    messages.success(
        request,
        "Leave Rejected Successfully."
    )

    return redirect("leave_list")