from django.db import models
from django.contrib.auth.models import User
from django.core.validators import RegexValidator


class Employee(models.Model):

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE
    )

    name = models.CharField(max_length=100)

    email = models.EmailField(unique=True)

    department = models.CharField(max_length=100)

    mobile_number = models.CharField(
        max_length=10,
        validators=[
            RegexValidator(
                regex=r'^\d{10}$',
                message="Enter a valid 10 digit mobile number."
            )
        ]
    )

    date_of_joining = models.DateField()

    def __str__(self):
        return self.name