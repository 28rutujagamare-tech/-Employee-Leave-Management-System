from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import (
    EmployeeViewSet,
    dashboard,
    employee_list,
    add_employee,
    edit_employee,
    delete_employee,
)

router = DefaultRouter()
router.register(r'employees', EmployeeViewSet, basename='employee')

urlpatterns = [
    path("", dashboard, name="dashboard"),
    path("employees/", employee_list, name="employee_list"),
    path("employee/add/", add_employee, name="add_employee"),
    path(
        "employee/edit/<int:id>/",
        edit_employee,
        name="edit_employee",
    ),
    path(
        "employee/delete/<int:id>/",
        delete_employee,
        name="delete_employee",
    ),
]

urlpatterns += router.urls