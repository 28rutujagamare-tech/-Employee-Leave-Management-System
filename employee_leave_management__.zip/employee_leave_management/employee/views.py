from django.shortcuts import render, redirect, get_object_or_404
from rest_framework import viewsets
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden

from .models import Employee
from .serializers import EmployeeSerializer
from emp_leaves.models import Leave


# ==========================
# REST API
# ==========================

class EmployeeViewSet(viewsets.ModelViewSet):
    """
    Handles GET All, GET by ID, POST, PUT and DELETE.
    Search:
    /api/employees/?search=John
    /api/employees/?search=1
    """

    queryset = Employee.objects.all().order_by("id")
    serializer_class = EmployeeSerializer

    def get_queryset(self):

        queryset = Employee.objects.all().order_by("id")

        search = self.request.query_params.get("search")

        if search:

            if search.isdigit():
                queryset = Employee.objects.filter(id=search)
            else:
                queryset = Employee.objects.filter(name__icontains=search)

        return queryset


# ==========================
# Django Web Views
# ==========================

@login_required
def dashboard(request):

    # Only HR can access dashboard
    if not request.user.is_staff:
        return HttpResponseForbidden("You are not authorized to access the dashboard.")

    total_employees = Employee.objects.count()
    total_leaves = Leave.objects.count()
    pending = Leave.objects.filter(status="Pending").count()
    approved = Leave.objects.filter(status="Approved").count()
    rejected = Leave.objects.filter(status="Rejected").count()

    context = {
        "total_employees": total_employees,
        "total_leaves": total_leaves,
        "pending": pending,
        "approved": approved,
        "rejected": rejected,
    }

    return render(request, "dashboard.html", context)


@login_required
def employee_list(request):

    # Only HR can manage employees
    if not request.user.is_staff:
        return HttpResponseForbidden("You are not authorized to view employees.")

    employees = Employee.objects.all()

    search = request.GET.get("search")

    if search:

        if search.isdigit():
            employees = Employee.objects.filter(id=search)
        else:
            employees = Employee.objects.filter(name__icontains=search)

    return render(
        request,
        "employee/employee_list.html",
        {"employees": employees},
    )


@login_required
def add_employee(request):

    # Only HR can add employees
    if not request.user.is_staff:
        return HttpResponseForbidden("You are not authorized.")

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        # Check duplicate username
        if User.objects.filter(username=username).exists():
            return render(
                request,
                "employee/add_employee.html",
                {"error": "Username already exists."}
            )

        user = User.objects.create_user(
            username=username,
            password=password
        )

        Employee.objects.create(
            user=user,
            name=request.POST.get("name"),
            email=request.POST.get("email"),
            department=request.POST.get("department"),
            mobile_number=request.POST.get("mobile_number"),
            date_of_joining=request.POST.get("date_of_joining"),
        )

        return redirect("employee_list")

    return render(request, "employee/add_employee.html")


@login_required
def edit_employee(request, id):

    # Only HR can edit employees
    if not request.user.is_staff:
        return HttpResponseForbidden("You are not authorized.")

    employee = get_object_or_404(Employee, id=id)

    if request.method == "POST":

        employee.name = request.POST.get("name")
        employee.email = request.POST.get("email")
        employee.department = request.POST.get("department")
        employee.mobile_number = request.POST.get("mobile_number")
        employee.date_of_joining = request.POST.get("date_of_joining")

        employee.save()

        return redirect("employee_list")

    return render(
        request,
        "employee/edit_employee.html",
        {"employee": employee},
    )


@login_required
def delete_employee(request, id):

    # Only HR can delete employees
    if not request.user.is_staff:
        return HttpResponseForbidden("You are not authorized.")

    employee = get_object_or_404(Employee, id=id)

    # Delete linked Django user first
    if employee.user:
        employee.user.delete()
    else:
        employee.delete()

    return redirect("employee_list")