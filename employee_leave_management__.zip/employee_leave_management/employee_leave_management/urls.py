from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', include('employee.urls')),
    path('', include('emp_leaves.urls')),

    path('api/', include('employee.urls')),
    path('api/', include('emp_leaves.urls')),

    path("accounts/", include("django.contrib.auth.urls")),
    path(
            'login/',
            auth_views.LoginView.as_view(),
            name='login'
        ),
    path(
        'logout/',
        auth_views.LogoutView.as_view(),
        name='logout'
    ),
]